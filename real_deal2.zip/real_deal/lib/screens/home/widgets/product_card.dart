import 'package:flutter/material.dart';

import '../../../values/custom_colors.dart';
import '../../../values/shadows.dart';
import '../../../values/styles.dart';
import 'add_to_cart_btn.dart';
import 'iterm_like_btn.dart';

class ProductCard extends StatelessWidget {
  const ProductCard({
    super.key,
    required this.image,
    required this.title,
    required this.sellMethod,
    required this.newPrice,
    required this.oldPrice,
  });
  final String image;
  final String title;
  final String sellMethod;
  final int newPrice, oldPrice;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Container(
        // width: 157,
        // height: 210,
        width: 157,
        // height: 251,
        decoration: ShapeDecoration(
          color: CustomColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          shadows: CustomShadows.shadowsAll,
        ),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10),
                  ),
                  child: Image.asset(
                    image,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: [
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          title,
                          style: Styles.regularInter14(
                            CustomColors.normalTextColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            newPrice.toString(),
                            style: Styles.regularInter13(
                              CustomColors.primaryColor,
                              fontWeight: FontWeight.w700,
                              letterSpacing: -.32,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            sellMethod,
                            style: Styles.regularInter10(
                              CustomColors.lightTextColor,
                              letterSpacing: 0.07,
                            ),
                          )
                        ],
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          oldPrice.toString(),
                          style: Styles.regularInter11(
                            CustomColors.grey,
                            fontWeight: FontWeight.w500,
                            lineThrough: true,
                            letterSpacing: -.32,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            const ItemLikeButton(),
            const AddToCartButton()
          ],
        ),
      ),
    );
  }
}
