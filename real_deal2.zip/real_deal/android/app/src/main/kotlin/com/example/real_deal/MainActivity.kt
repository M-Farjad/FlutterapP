package com.example.real_deal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
