package com.example.ads_mob_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
