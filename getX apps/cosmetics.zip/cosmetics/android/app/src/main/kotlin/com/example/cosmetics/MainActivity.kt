package com.example.cosmetics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
