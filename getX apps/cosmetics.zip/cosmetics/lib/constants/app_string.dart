import 'package:flutter/material.dart';

class AppString {
  static const fetchApiData = 'Fetch API data';
  static const productList = 'Product list';
}
