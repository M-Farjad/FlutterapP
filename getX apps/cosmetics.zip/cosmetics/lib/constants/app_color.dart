import 'package:flutter/material.dart';

class AppColor {
  static const purpleColor = Colors.deepPurple;
  static const grey = Colors.grey;
  static final grey200 = Colors.grey[200];
}
