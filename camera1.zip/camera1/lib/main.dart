import 'dart:developer';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const CameraApp(),
    );
  }
}

class CameraApp extends StatefulWidget {
  const CameraApp({super.key});

  @override
  State<CameraApp> createState() => _CameraAppState();
}

class _CameraAppState extends State<CameraApp> {
  late CameraController _controller;
  Image? imageFile;

  @override
  void initState() {
    _initializeCamera();
    super.initState();
  }

  @override
  dispose() {
    super.dispose();
    _controller.dispose();
  }

  Future<void> _initializeCamera() async {
    final camera = await getCamera();
    _controller = CameraController(camera, ResolutionPreset.medium);
    await _controller.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});
    }).catchError((Object e) {
      if (e is CameraException) {
        switch (e.code) {
          case 'CameraAccessDenied':
            log('access denied');
            break;
          default:
            log('error');
            log(e.description.toString());
        }
      }
    });
  }

  Future<CameraDescription> getCamera() async {
    final cameras = await availableCameras();
    final frontCamera = cameras.firstWhere(
      (camera) => camera.lensDirection == CameraLensDirection.front,
      orElse: () => cameras.first,
    );
    return frontCamera;
  }

  _captureImage() async {
    if (!_controller.value.isInitialized) {
      return;
    }
    try {
      final XFile imageFile = await _controller.takePicture();
      setState(() {
        this.imageFile = Image.file(
          File(imageFile.path),
          fit: BoxFit.fill,
        );
      });
    } catch (e) {
      log(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Camera App')),
      body: SafeArea(
        child: Column(
          children: [
            Align(
              child: Container(
                width: 208,
                height: 210,
                decoration: ShapeDecoration(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  color: Colors.white.withOpacity(.8),
                ),
                padding: const EdgeInsets.all(4),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: !_controller.value.isInitialized
                      ? null
                      : imageFile == null
                          ? CameraPreview(_controller)
                          : Transform(
                              alignment: Alignment.center,
                              transform: Matrix4.rotationY(3.14159265359),
                              child: imageFile!,
                            ),
                ),
              ),
            ),
            // ElevatedButton(onPressed: () {}, child: const Text('Open Camera'))
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _captureImage,
        child: const Icon(Icons.camera),
      ),
    );
  }
}
